$(document).ready(function(){



    $.ajax({
        type: "GET",
        url: "alunos.json",
        dataType: "json",
        beforeSend: function (jqXHR) {
            $("#info").show();
        },
        success: function (result, textStatus, jqXHR) {
            if(result['sucesso'] === true){
                $.each(result['alunos'], function (index, value) {
                    $('#alunos').append('<tr><td>'+value.nome+'</td><td>'+value.idade+'</td><td>'+value.email+'</td></tr>')
                });
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
        },
        complete: function (jqXHR, textStatus) {
            $("#info").hide();
        }
    });



});