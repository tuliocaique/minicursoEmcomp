$( "#inscricao" ).submit(function(event) {
    let content = $("#inscricao").serialize();
    console.log(content);
    alert("Cadastrado");
    $('#inscricao').hide();

    event.preventDefault();
});

$( "#clicaAqui" ).click(function(event) {
    alert("Olá Mundo!");
});