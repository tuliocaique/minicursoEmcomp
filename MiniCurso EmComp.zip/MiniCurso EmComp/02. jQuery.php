<!DOCTYPE html>
<html lang=pt">
<head>
    <meta charset="UTF-8">
    <title>jQuery</title>

    <!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- CSS do Bootstrap (obrigatório) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
</head>
<body>


    <div class="container mt-5 p-2">

        <form class="form" id="inscricao">
            <input type="email" id="emailUsuario" name="emailUsuario"  value="Insira seu email" required/>
            <input type="submit"  class="btn btn-primary" value="Cadastrar"/>
        </form>

        <hr class="mt-5">

        <button class="btn btn-info" id="clicaAqui">Clica Aqui</button>
    </div>


    <script src="https://code.jquery.com/jquery.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="assets/js/jQuery_exemplo.js"></script>
</body>
</html>