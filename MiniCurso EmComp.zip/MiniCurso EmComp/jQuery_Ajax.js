//AJAX: METODO RESPONSAVEL POR ENVIAR OS DADOS DE FORMA ASSINCRONA
$.ajax({
    type: "POST", //METODO DE REQUISIÇÃO: POST, GET, PUT, DELETE...
    url: "https://emcomp.com.br/api/cardapio",  //URL DA API QUE RECEBERÁ OU RETORNARÁ OS DADOS
    data: content, //ARRAY CONTENDO OS DADOS A SEREM ENVIADOS (OPCIONAL)
    dataType: "json",
    beforeSend: function (jqXHR) {
        //FUNÇÃO EXECUTADA ANTES DO ENVIO DA REQUISIÇÃO
    },
    success: function (result, textStatus, jqXHR) {
        //QUANDO A REQUISIÇÃO FOR REALIZADA COM SUCESSO
        /*      Parametros:

                result: Objeto contendo os dados desejados da api
                textStatus: String que exibe o status da requisição ("null", "timeout", "error", "abort", ou "parsererror")
                jqXHR: Objeto
         */
    },
    error: function (jqXHR, textStatus, errorThrown) {
        //SE HOUVER ALGUM ERRO OU FALHA DURANTE A REQUISIÇÃO
        /*      Parametros:

                jqXHR: Objeto
                textStatus: String que exibe o status da requisição ("null", "timeout", "error", "abort", ou "parsererror")
                errorThrown: String que exibe a menssagem de erro do HTTP ("Not Found", "Internal Server Error", ...)
         */
    },
    complete: function (jqXHR, textStatus) {
        //INDEPENDENTE DE ERRO OU SUCESSO, A FUNÇÃO É SEMPRE EXECUTADA APÓS COMPLETADA A REQUISÇÃO
        /*      Parametros:

                jqXHR: Objeto
                textStatus: String que exibe o status da requisição ("null", "timeout", "error", "abort", ou "parsererror")
         */
    }
});