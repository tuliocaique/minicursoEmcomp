<!DOCTYPE html>
<html lang="pt">
<head>
    <title>AJAX - GET</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 id="info">Carregando</h2>
    <table class="table">
        <thead>
        <tr>
            <th>Nome</th>
            <th>Idade</th>
            <th>Email</th>
        </tr>
        </thead>
        <tbody id="alunos">

        </tbody>
    </table>
</div>


<script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
<script src="assets/js/jQuery_Ajax_exemplo.js"></script>
</body>
</html>