<!DOCTYPE html>
<html>
<head>
    <title>Bootstrap Template</title>
    <!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- CSS do Bootstrap (obrigatório) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
</head>

<body class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 bg-primary">
                Linha com 12 colunas em qualquer dispositivo
            </div>
        </div>

        <div class="row">
            <div class="col-lg-4 bg-danger">
                coluna 1
            </div>
            <div class="col-lg-4 bg-warning">
                coluna 2
            </div>
            <div class="col-lg-4 bg-secondary">
                coluna 3
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 col-sm-12 bg-success">
                coluna 1
            </div>
            <div class="col-md-4 col-sm-12 bg-danger">
                coluna 2
            </div>
            <div class="col-md-4 col-sm-12 bg-primary">
                coluna 3
            </div>
        </div>
    </div>


    <!-- jQuery (obrigatório caso você use o Javascript do Bootstrap) -->
    <script src="https://code.jquery.com/jquery.js"></script>

    <!-- Javascript do Bootstrap (opcional) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</body>
</html>