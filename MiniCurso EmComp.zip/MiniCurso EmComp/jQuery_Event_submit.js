//ID DO FORMULARIO
$( "#inscricao" ).submit(function(event) {
    //QUANDO CLICADO NO BOTÃO SUBMIT DO FORMULARIO TODAS AS AÇÕES AQUI DENTRO SÃO EXECUTADAS

    let content = $("#inscricao").serialize(); //PEGA TODOS OS DADOS DO INPUTS DO FORMULARIO E ARMAZENA DENTRO DE UMA VARIAVEL NO FORMATO:    name=Valor&name2=Valor2&...
    console.log(content);  //EXIBE NO CONSOLE OS DADOS CAPTURADOS

        /*AJAX para envio das informações para o back-end*/


    event.preventDefault();
});